#ifndef UTILS_HPP
#define UTILS_HPP

#include <string>

void printMessage(const std::string &msg);

#endif
