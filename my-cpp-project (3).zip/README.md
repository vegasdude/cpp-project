# My C++ Project

This is a simple modular C++ project template for GitHub.

## Build
```bash
make
./app
```

## Structure
- **src/** — source code  
- **include/** — header files  
- **build/** — compiled output  
