#include <iostream>
#include "utils.hpp"

void printMessage(const std::string &msg) {
    std::cout << msg << std::endl;
}
