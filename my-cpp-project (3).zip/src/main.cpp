#include <iostream>
#include "utils.hpp"

int main() {
    std::cout << "Hello from C++ project!" << std::endl;
    printMessage("This is a modular C++ project.");
    return 0;
}
